from urllib import parse
TOKEN = "token bota"
CLIENT_SECRET = "client secret - v záložce OAuth2"
REDIRECT_URI = "Link na který se vše bude redirectovat"
OAUTH_URL = f"oauth url, viz"