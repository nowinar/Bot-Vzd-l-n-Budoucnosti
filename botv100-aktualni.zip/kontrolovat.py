import time
import sys
import discord
import json
allowed_users = []
pouzivatele = {}
intents = discord.Intents.default()
intents.members = True
client = discord.Client(intents=intents)
@client.event
async def on_ready():
    for guild in client.guilds:
        mezi = []
        for member in guild.members:
            for a in member.roles:
                if str(a) == "Moderátor":
                    mezi.append(member.name)
                    allowed_users.append(member)
        pouzivatele[guild.name] = mezi
        print(mezi)
    with open("users.json", mode="w") as f:
        f.write(json.dumps(pouzivatele))
    sys.exit(0)
client.run("token bota")